import React from 'react';

export const ReportsWithScriptLoaded = () => {

    return (
        <div id='report-container'>
            <div id='learnosity_report'></div>
        </div>
    );
};