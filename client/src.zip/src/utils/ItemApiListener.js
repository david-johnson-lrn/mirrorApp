/* eslint-disable no-undef */
import React from 'react';

export const QuizListener = (authentication) => {

    let learnosityObj = '';

    if (authentication) {

        if (typeof LearnosityItems != 'undefined') {
            //this stores entire javascript library https://reference.learnosity.com/items-api/initialization
            learnosityObj = LearnosityItems.init(authentication, {
                readyListener() {
                    console.log('👍🏼 <<< Learnosity Assess API is ready >>> 🧘🏼');

                    //On item load event, introduce custom logic to store number of current item attempt https://reference.learnosity.com/assess-api/events/supported/item.load
                    learnosityObj.on("item:load", function () {
                        let studentCount = 0
                        let response_id = learnosityObj.getCurrentItem().response_ids[0];
                        //Question level event to increment current attempt count on each interaction of response https://reference.learnosity.com/questions-api/events/question/changed
                        learnosityObj.question([response_id]).on("changed", function (q) {
                            studentCount++;

                            console.log(`Student answer count ${studentCount}`)
                        })
                    })
                },
                errorListener(err) {
                    console.log('error', err);
                }
            })
        }

        if (typeof LearnosityReports != 'undefined') {

            learnosityObj = LearnosityReports.init(authentication, {
                readyListener() {
                    console.log('👍🏼 <<< Learnosity Reports API is ready >>> 🧘🏼');

                },
                errorListener(err) {
                    console.log('error', err);
                }
            })
        }
        if (typeof LearnosityAuthor != 'undefined') {

            learnosityObj = LearnosityAuthor.init(authentication, {
                readyListener() {
                    console.log('👍🏼 <<< Learnosity Author API is ready >>> 🧘🏼');

                },
                errorListener(err) {
                    console.log('error', err);
                }
            })
        }

    }

    return (
        <>
            {learnosityObj}
        </>
    )
}
